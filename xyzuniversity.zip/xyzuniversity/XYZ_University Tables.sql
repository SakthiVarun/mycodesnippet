create database XYZ_University

use XYZ_University


create table students_inventory (StudentID int Identity(1,1) primary key,
								 StudentName nvarchar (100),
								 Mode nvarchar (20),
								 Age int,
								 Department nvarchar (20)
)


insert into students_inventory values ('Sakthi','lateral', 23, 'ECE')

select * from students_inventory