const mssql = require("mssql");

const sqlconfig = {
    server: "localhost",
    user: "sa",
    password: "admin",
    database: "XYZ_University",
    options:{
        trustServerCertification: true,
        trustServerCertificate: true
    }
}


const getAllData = async (request, response)=>{
    try{
        let dba = await mssql.connect(sqlconfig);
        console.log("db connected");
        
        let result = await dba.request().query(`select * from students_inventory`);
        response.status(200).json(result.recordset);
        console.log(response.status(200));
    }
    catch(e){
        console.log("error in getAllData", e)
    }
}


module.exports = {getAllData}