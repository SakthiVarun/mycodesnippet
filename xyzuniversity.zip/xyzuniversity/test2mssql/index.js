// Import Express Modle
const express = require('express');

// Import the Query File
const db = require('./queries');

const mssql = require("mssql");

// Create am instance for express
const app = express();

const port = 8080;

// use of express Json
app.use(express.json())

app.use((req, res, next)=>{
    res.setHeader('Access-Control-Allow-Orgin','*');
    res.setHeader(
        'Access-Control-Allow-Methods',
        'Options, GET, POST, PUT, PATCH, DELETE'
    );
    res.setHeader('Access-Control-Allow-Headers','Content-Type, Authorization');
    next();
})


app.get('/getAllData/',db.getAllData);

app.listen(port,()=>{
    console.log(`App run aagudhu da dubuku PFA ${port}`)
})