import { useState, useEffect } from "react";

function TestApi() {
  const [masterStudent, setmasterStudent] = useState([{}]);

  function testData() {
    // fetch('api/getAllData/').then(
    //     response => response.json()
    // ).then(

    //     data =>{
    //         setmasterStudent(data)
    //     }
    // )

    // console.log("this is master student data", masterStudent)
  }


  useEffect(() => {
    testData();
  });

  return <>Hi</>;
}

export default TestApi;
